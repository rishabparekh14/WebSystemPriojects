# FB-GoogleCV-ImageCateogryDetection

### URL - [https://facebookvision.uc.r.appspot.com](https://facebookvision.uc.r.appspot.com)